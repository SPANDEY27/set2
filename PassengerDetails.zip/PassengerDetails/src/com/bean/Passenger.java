package com.bean;

public class Passenger {

	private String passengerName;
	private String gender;
	private int age;
	public String getPassengerName() {
		return passengerName;
	}
	public void setPassengerName(String passengerName) {
		this.passengerName = passengerName;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	
	public double calculateDiscountedTicketPrice()
	{
		if(this.getAge() >=10)
			return 100.0;
		return 90.0;
	}
	
}
