package com.ui;

import com.bean.*;
import com.utility.*;
import java.util.*;

public class UserInterface {
	public static void main(String[] args) {
		int noOfProducts = 0;
		Railways railway = new Railways();
		railway.setPassengerList(new ArrayList<Passenger>());
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number of passengers");
		noOfProducts = Integer.parseInt(sc.nextLine());

		for (int i = 0; i < noOfProducts; i++) {
			Passenger passenger = new Passenger();
			System.out.println("Enter the passenger name");
			String pName = sc.nextLine();
			passenger.setPassengerName(pName);
			System.out.println("Enter the passenger gender");
			String pGenger = sc.nextLine();
			passenger.setGender(pGenger);
			System.out.println("Enter the passenger age");
			int age = Integer.parseInt(sc.nextLine());
			passenger.setAge(age);
			railway.addPassenger(passenger);
		}

		List<Passenger> passList = railway.getPassengerList();
		for (Passenger pass : passList) {
			System.out.println(pass.getPassengerName() + " " + pass.calculateDiscountedTicketPrice());
		}

		System.out.println("Enter the gender to be searched");
		String gender = sc.nextLine();
		System.out.println(railway.countBasedOnGender(gender));

	}

}
