package com.ui;

import com.utility.*;
import java.util.*;
import java.util.Map.Entry;

public class UserInterface {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Bazaar b = new Bazaar();
		TreeMap<Integer, String> map = new TreeMap<Integer, String>();
		b.setPolicyMap(map);
		System.out.println("Enter the no of Policy names you want to store");
		String num = sc.nextLine();
		int n = Integer.parseInt(num);
		while (n-- > 0) {
			System.out.println("Enter the Policy ID");
			String s = sc.nextLine();
			int policyId = Integer.parseInt(s);
			System.out.println("Enter the Policy Name");
			String policyName = sc.nextLine();
			b.addPolicyDetails(policyId, policyName);
		}
		Map<Integer, String> policyDetails = b.getPolicyMap();
		Set<Integer> keySet = policyDetails.keySet();
		for (Integer key : keySet) {
			System.out.println(key + " " + policyDetails.get(key));
		}
		System.out.println("Enter the policy type to be searched");
		String policyType = sc.nextLine();
		List<Integer> list = b.searchBasedOnPolicyType(policyType);
		for (Integer id : list) {
			System.out.println(id);
		}
		sc.close();
	}

}