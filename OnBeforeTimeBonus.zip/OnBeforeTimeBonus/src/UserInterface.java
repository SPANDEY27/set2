import java.util.ArrayList;
import java.util.Scanner;

public class UserInterface {

	public static void main(String a[]) {
		Scanner sc = new Scanner(System.in);
		int noOfEmployees = sc.nextInt();
		String employees[] = new String[noOfEmployees];
		for (int i = 0; i < noOfEmployees; i++) {
			employees[i] = sc.next();
		}
		ArrayList<String> al = new ArrayList<String>();
		ArrayList<String> bl = new ArrayList<String>();
		for (int i = 0; i < noOfEmployees; i++) {
			String s[] = new String[3];
			s = employees[i].split(",");
			s[1] = s[1].replace(":", "");
			s[2] = s[2].replace(":", "");
			int x = Integer.parseInt(s[1]);
			int y = Integer.parseInt(s[2]);
			if (x >= y) {
				al.add(s[0]);
			} else
				bl.add(s[0]);
		}
		if (!al.isEmpty()) {
			for (String string : al) {
				System.out.print(string + " ");
			}
			System.out.println("are eligible for Bonus");
		} else {
			for (String string : bl) {
				System.out.print(string + " ");
			}
			System.out.println("are not eligible for Bonus");
		}

		sc.close();
	}

}
