import java.util.Scanner;

public class UserInterface {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Name");
		String name=sc.nextLine();
		System.out.println("Enter Department");
		String dept=sc.nextLine();
		System.out.println("Enter Gender");
		char gender = sc.nextLine().charAt(0);

		Participant obj = new Participant();
		obj.setName(name);
		obj.setDepartment(dept);
	
		// fill the code
		try{
            obj.setGender(gender);
            System.out.println("Registration Successful");
        }
        catch(GenderInValidException e){
            System.out.println("Invalid Gender");
        }

	}
	
}


