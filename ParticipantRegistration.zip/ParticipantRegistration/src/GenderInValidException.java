//make the necessary change to make this class an Exception 
public class GenderInValidException extends Exception {
 public GenderInValidException(){
	       
	    }
	    public GenderInValidException(String message){
	        super(message);
	    }
	
}
