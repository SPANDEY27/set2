
public class Participant {
	private String name;
	private char gender;
	private String department;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public char getGender() {
		return gender;
	}
	public void setGender(char gender) throws GenderInValidException {
        if (gender == 'M' || gender == 'F'|| gender == 'T' || gender == 'm' || gender == 'f'|| gender == 't'){
                this.gender = gender;
    }
    else{
        throw new GenderInValidException("Invalid Gender");
    }
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}	
}
