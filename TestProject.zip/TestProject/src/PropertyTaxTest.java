import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class PropertyTaxTest {
	 @Test
     public void TestCalProp1(){
         PropertyTax proTax1=new PropertyTax(101, "Commercial", 100);
         double actual=proTax1.calculatePropertyTax();
         double expected=500;
         assertTrue(expected==actual);
     }
     @Test
     public void TestCalProp2(){
         PropertyTax proTax2=new PropertyTax(102, "Private", 1000);
         double actual=proTax2.calculatePropertyTax();
         double expected=0.0;
         assertTrue(expected==actual);
     }
}
